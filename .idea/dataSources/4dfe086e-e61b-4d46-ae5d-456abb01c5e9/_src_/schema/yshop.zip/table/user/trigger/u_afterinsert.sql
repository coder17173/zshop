CREATE TRIGGER u_afterinsert
AFTER INSERT ON user
FOR EACH ROW
  insert into wallet(uid) values (new.uid);
